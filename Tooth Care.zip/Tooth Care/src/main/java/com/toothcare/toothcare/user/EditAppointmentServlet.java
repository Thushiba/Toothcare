package com.toothcare.toothcare.user;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.sql.*;

@WebServlet(urlPatterns = "/editAppointment")
public class EditAppointmentServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        String userName = (String) session.getAttribute("name");

        Connection con = null;
        RequestDispatcher dispatcher = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3308/ToothCare?useSSL=false", "root", "1234");

            PreparedStatement checkStmt = con.prepareStatement("SELECT * FROM channelling WHERE user_name = ?");
            checkStmt.setString(1, userName);
            ResultSet resultSet = checkStmt.executeQuery();

            if (resultSet.next()) {
                String existingAppointmentDate = resultSet.getString("appointment_date");
                String existingAppointmentTime = resultSet.getString("appointment_time");
                String existingPatientName = resultSet.getString("patient_name");
                String existingAddress = resultSet.getString("address");
                String existingTelephone = resultSet.getString("telephone");
                String existingRegistrationFee = resultSet.getString("registration_fee");
                String existingTreatmentType = resultSet.getString("treatment_type");

                request.setAttribute("existingAppointmentDate", existingAppointmentDate);
                request.setAttribute("existingAppointmentTime", existingAppointmentTime);
                request.setAttribute("existingPatientName", existingPatientName);
                request.setAttribute("existingAddress", existingAddress);
                request.setAttribute("existingTelephone", existingTelephone);
                request.setAttribute("existingRegistrationFee", existingRegistrationFee);
                request.setAttribute("existingTreatmentType", existingTreatmentType);

                request.setAttribute("hasExistingAppointment", true);
            } else {
                request.setAttribute("hasExistingAppointment", false);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (con != null) {
                    con.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        dispatcher = request.getRequestDispatcher("update.jsp");
        dispatcher.forward(request, response);
    }
}


