package com.toothcare.toothcare.user;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

@WebServlet("/channelForm")
public class ChannelServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String patientName = request.getParameter("patientName");
        String address = request.getParameter("address");
        String telephone = request.getParameter("telephone");
        String appointmentDate = request.getParameter("appointmentDate");
        String appointmentTime = request.getParameter("appointmentTime");
        String registrationFee = request.getParameter("registrationFee");
        String treatmentType = request.getParameter("treatmentType");

        HttpSession session = request.getSession();
        String userName = (String) session.getAttribute("name");

        RequestDispatcher dispatcher;
        Connection con = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3308/ToothCare?useSSL=false", "root", "1234");
            PreparedStatement pst = con.prepareStatement("INSERT INTO channelling(user_name, appointment_date, appointment_time, patient_name, address, telephone, registration_fee, treatment_type, now_local_time) VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())");
            pst.setString(1, userName);
            pst.setString(2, appointmentDate);
            pst.setString(3, appointmentTime);
            pst.setString(4, patientName);
            pst.setString(5, address);
            pst.setString(6, telephone);
            pst.setString(7, registrationFee);
            pst.setString(8, treatmentType);

            int rowCount = pst.executeUpdate();

            if (rowCount > 0) {
                request.setAttribute("status", "success");
            } else {
                request.setAttribute("status", "failed");
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (con != null) {
                    con.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        dispatcher = request.getRequestDispatcher("index.jsp");
        dispatcher.forward(request, response);
    }
}
