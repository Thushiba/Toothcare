package com.toothcare.toothcare.user;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

@WebServlet(name = "UpdateAppointmentServlet", value = "/UpdateAppointmentServlet")
public class UpdateAppointmentServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String appointmentDate = request.getParameter("appointmentDate");
        String appointmentTime = request.getParameter("appointmentTime");
        String patientName = request.getParameter("patientName");
        String address = request.getParameter("address");
        String telephone = request.getParameter("telephone");
        String registrationFee = request.getParameter("registrationFee");
        String treatmentType = request.getParameter("treatmentType");

        HttpSession session = request.getSession();
        String userName = (String) session.getAttribute("name");

        Connection con = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3308/ToothCare?useSSL=false", "root", "1234");

            PreparedStatement updateStmt = con.prepareStatement("UPDATE channelling SET appointment_date = ?, appointment_time = ?, patient_name = ?, address = ?, telephone = ?, registration_fee = ?, treatment_type = ? WHERE user_name = ?");
            updateStmt.setString(1, appointmentDate);
            updateStmt.setString(2, appointmentTime);
            updateStmt.setString(3, patientName);
            updateStmt.setString(4, address);
            updateStmt.setString(5, telephone);
            updateStmt.setString(6, registrationFee);
            updateStmt.setString(7, treatmentType);
            updateStmt.setString(8, userName);
            updateStmt.executeUpdate();

            response.sendRedirect("index.jsp");
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (con != null) {
                    con.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }

        }
    }
}
