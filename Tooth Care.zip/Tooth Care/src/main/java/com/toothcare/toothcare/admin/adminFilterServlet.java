package com.toothcare.toothcare.admin;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.sql.*;

@WebServlet("/appFilter")
public class adminFilterServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String appointmentDate = request.getParameter("appointmentDate");

        // Set the appointmentDate as an attribute in the request
        request.setAttribute("appointmentDate", appointmentDate);

        // Forward the request to adminFilter.jsp
        RequestDispatcher dispatcher = request.getRequestDispatcher("adminFilter.jsp");
        dispatcher.forward(request, response);

        }
}
