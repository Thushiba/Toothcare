package com.toothcare.toothcare.admin;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.sql.*;

@WebServlet("/appSearch")
public class adminSearchServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String appointmentID = request.getParameter("appID");

        Connection con = null;
        PreparedStatement retrieveStmt = null;
        ResultSet resultSet = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3308/ToothCare?useSSL=false", "root", "1234");

            retrieveStmt = con.prepareStatement("SELECT * FROM channelling WHERE channel_id = ?");
            retrieveStmt.setString(1, appointmentID);
            resultSet = retrieveStmt.executeQuery();

            if (resultSet.next()) {
                // Retrieve appointment details from the ResultSet
                String appointmentDate = resultSet.getString("appointment_date");
                String appointmentTime = resultSet.getString("appointment_time");
                String patientName = resultSet.getString("patient_name");
                String address = resultSet.getString("address");
                String telephone = resultSet.getString("telephone");
                String registrationFee = resultSet.getString("registration_fee");
                String treatmentType = resultSet.getString("treatment_type");

                // Set appointment details as request attributes to use in JSP
                request.setAttribute("appointmentID", appointmentID);
                request.setAttribute("appointmentDate", appointmentDate);
                request.setAttribute("appointmentTime", appointmentTime);
                request.setAttribute("patientName", patientName);
                request.setAttribute("address", address);
                request.setAttribute("telephone", telephone);
                request.setAttribute("registrationFee", registrationFee);
                request.setAttribute("treatmentType", treatmentType);

                // Forward to a JSP to display the appointment details
                RequestDispatcher dispatcher = request.getRequestDispatcher("adminSearch.jsp");
                dispatcher.forward(request, response);
            } else {
                // No appointment found in the database
                RequestDispatcher dispatcher = request.getRequestDispatcher("noAppointmentFound.jsp");
                dispatcher.forward(request, response);
            }
        } catch (Exception e) {
            e.printStackTrace();
            // Handle exceptions or display an error message
        } finally {
            try {
                if (resultSet != null) {
                    resultSet.close();
                }
                if (retrieveStmt != null) {
                    retrieveStmt.close();
                }
                if (con != null) {
                    con.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
